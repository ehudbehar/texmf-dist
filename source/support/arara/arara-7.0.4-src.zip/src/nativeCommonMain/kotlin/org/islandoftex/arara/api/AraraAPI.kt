// SPDX-License-Identifier: BSD-3-Clause
package org.islandoftex.arara.api

public actual object AraraAPI {
    @Suppress("MayBeConst")
    public actual val version: String = "7.0.4"
}
